#include<bits/stdc++.h>
using namespace std;

void Dfs(vector<int> adj[], int v, stack<int>& st, vector<bool>& visited) {
    visited[v] = true;
    for (auto i : adj[v]) {
        if (!visited[i]) {
            Dfs(adj, i, st, visited);
        }
    }
    st.push(v);
}

void DfsT(vector<int> adj[], int v, vector<bool>& visited) {
    visited[v] = true;
    for (auto i : adj[v]) {
        if (!visited[i]) {
            DfsT(adj, i, visited);
        }
    }
}

int ConnectedComponents(vector<int> adj[], int V) {
    vector<bool> visited(V, false);
    stack<int> st;

    for (int i = 0; i < V; i++) {
        if (!visited[i]) {
            Dfs(adj, i, st, visited);
        }
    }

    vector<int> adjT[V];
    for (int i = 0; i < V; i++) {
        visited[i] = false;
        for (auto it : adj[i]) {
            adjT[it].push_back(i);
        }
    }

    int scc = 0;
    while (!st.empty()) {
        int node = st.top();
        st.pop();
        if (!visited[node]) {
            scc++;
            DfsT(adjT, node, visited);
        }
    }

    return scc;
}

int main() {
    int V, E;
    cin >> V >> E;

    vector<int> adj[V];
    for (int i = 0; i < E; ++i) {
        int u, v;
        cin >> u >> v;
        adj[u].push_back(v);
    }

    int scc = ConnectedComponents(adj, V);
    cout << "Number of Strongly Connected Components: " << scc << endl;

    return 0;
}