#include<bits/stdc++.h>
using namespace std;

bool Dfs(vector<int> adj[], int v, stack<int>& st, vector<bool>& visited, vector<bool>& currentPath) {
    visited[v] = true;
    currentPath[v] = true;

    for(auto i : adj[v]) {
        if(!visited[i]) {
            if(Dfs(adj, i, st, visited, currentPath))
                return true;
        }
        else if(currentPath[i]) {
            return true;
        }
    }

    currentPath[v] = false;
    st.push(v);
    return false;
}

bool Toppo(vector<int> adj[], int V) {
    vector<bool> visited(V, false);
    vector<bool> currentPath(V, false);
    stack<int> st;

    for(int i = 0; i < V; i++) {
        if(!visited[i]) {
            if(Dfs(adj, i, st, visited, currentPath))
                return false; 
        }
    }

    return true;
}

int main() {
    int V, E;
    cin >> V >> E;

    vector<int> adj[V];
    for (int i = 0; i < E; ++i) {
        int u, v;
        cin >> u >> v;
        adj[u].push_back(v);
    }

    if(Toppo(adj, V)) {
        cout << "Yes, it is a Directed Acyclic Graph" << endl;
    } else {
        cout << "No, it contains cycles" << endl;
    }

    return 0;
}
