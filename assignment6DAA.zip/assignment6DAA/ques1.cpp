#include<bits/stdc++.h>
using namespace std;

void Dfs(vector<int> adj[], int v, stack<int> &st, vector<bool> &visited) {
    visited[v] = true;
    for(auto i : adj[v]){
        if(!visited[i]){
            Dfs(adj, i, st, visited);
        }
    }
    st.push(v);
}

void TopologicalSort(vector<int> adj[], int V) {
    stack<int> st;
    vector<bool> visited(V, false);
    for(int i = 0; i < V; i++){
        if(!visited[i]){
            Dfs(adj, i, st, visited);
        }
    }

    while(!st.empty()){
        cout << st.top() << " ";
        st.pop();
    }
}

int main() {
    int V,E;
    cin >> V >> E;

    vector<int> adj[V];

    for(int i = 0; i < E; i++){
        int u, v;
        cin >> u >> v;
        adj[u].push_back(v);
    }

    cout << "Topological Sort is: ";
    TopologicalSort(adj, V);

    return 0;
}
